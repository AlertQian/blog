<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:71:"D:\wamp\www\gz91\public/../application/myadmin\view\article\artall.html";i:1499418029;s:68:"D:\wamp\www\gz91\public/../application/myadmin\view\layout\base.html";i:1499329034;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <title>AlertQian的博客</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" type="text/css" href="/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="/blog/css/base.css">
    <link rel="stylesheet" type="text/css" href="/blog/css/admin.css">
    <link rel="stylesheet" type="text/css" href="/blog/css/fakeloader.css">
    
<style type="text/css">
	.article{margin-top: 20px;}
	.divwrap{padding: 15px;}
	.glyp {top: 0px;cursor: pointer;}
	.addart{height: 34px;line-height: 34px;}
</style>

    <script type="text/javascript" src="/bootstrap/js/jquery-1.11.3.min.js"></script>
    <script type="text/javascript" src="/bootstrap/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="/blog/js/base.js"></script>
    <script type="text/javascript" src="/blog/js/admin.js"></script> 
    <script type="text/javascript" src="/blog/js/fakeloader.min.js"></script> 
     
</head>
<body>
    <div class="wrapper">
        

<div class="article">
    <div class="search">
	    <div class="col-md-5 col-sm-5">
			<div class="input-group">
				<input type="text" class="form-control" placeholder="标题">
				<span class="input-group-addon glyphicon glyphicon-search glyp"></span>
			</div>
		</div>
		<div class="col-md-7 col-sm-7 addart text-right" style="float: right;">
			<a href="<?php echo url('article/artadd'); ?>"><span class="glyphicon glyphicon-plus"></span> 添加文章</a>
		</div>
		<div class="clearfix"></div>
	</div>
	<div class="divwrap">
		<table class="table table-striped">
		  <caption>全部文章 <span class="badge badge-info">5</span></caption>
		  <thead>
		    <tr>
		      <th>选项</th>
		      <th>标题</th>
		      <th>作者</th>
		      <th>分类目录</th>
		      <th>日期</th>
		    </tr>
		  </thead>
		  <tbody>
		    <tr>
		      <td><input type="checkbox"></td>
		      <td>Bangalore</td>
		      <td>560001</td>
		      <td>Bangalore</td>
		      <td>560001</td>
		    </tr>
		  </tbody>
		</table>
	</div>
	<div class="fakeloader"></div>
</div>

    </div>
</body>
</html>