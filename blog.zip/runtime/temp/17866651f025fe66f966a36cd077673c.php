<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:67:"D:\wamp\www\gz91\public/../application/myadmin\view\art\artadd.html";i:1499850246;s:68:"D:\wamp\www\gz91\public/../application/myadmin\view\layout\base.html";i:1500517064;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <title>博客后台管理系统</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" type="text/css" href="/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="/blog/css/base.css">
    <link rel="stylesheet" type="text/css" href="/blog/css/admin.css">
    <link rel="stylesheet" type="text/css" href="/blog/css/fakeloader.css">
    
<link rel="stylesheet" type="text/css" href="/summernote/summernote.css">
<style type="text/css">
	.article{margin-top: 20px;}
	.divwrap{padding-left: 15px;padding-bottom: 10px;}
	.glyp {top: 0px;cursor: pointer;}
	.addart{height: 34px;line-height: 34px;}
</style>

    <script type="text/javascript" src="/bootstrap/js/jquery-1.11.3.min.js"></script>
    <script type="text/javascript" src="/bootstrap/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="/blog/js/base.js"></script>
    <script type="text/javascript" src="/blog/js/admin.js"></script> 
    <script type="text/javascript" src="/blog/js/fakeloader.min.js"></script> 
    
<script type="text/javascript" src="/summernote/summernote.min.js"></script>
 
</head>
<body>
    <div class="wrapper">
        

<div class="article">
    <div>
        <div class="divwrap"><h3>撰写新文章</h3></div>
        <form role="form" id="myForm">
	    <div class="col-md-10 col-sm-10">   
			  <div class="form-group">
			    <input type="text" class="form-control" id="name" placeholder="在此输入标题">
			  </div>
			  <div id="summernote"></div>
		</div>
		<div class="col-md-2 col-sm-2">
			<div class="panel panel-default">
			    <div class="panel-heading">文章类型</div>
			    <ul class="list-group radio">
			        <?php if(is_array($ret) || $ret instanceof \think\Collection): $i = 0; $__LIST__ = $ret;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$ret): $mod = ($i % 2 );++$i;?>
			        <li class="list-group-item"><label><input type="radio" name="artype" value="<?php echo $ret['id']; ?>"><?php echo $ret['item']; ?></label></li>
			        <?php endforeach; endif; else: echo "" ;endif; ?>
			        <li class="list-group-item"><button type="submit" class="btn btn-primary btn-block" id="artadd">提交</button></li>
			    </ul>
			</div>
		</div>
		<div class="clearfix"></div>
		</form>
	</div>
	
	<div class="fakeloader"></div>
</div>
<script type="text/javascript">
	$(document).ready(function() {
        $('#summernote').summernote({
			height: 380, 
			minHeight: null,
			maxHeight: null,
			placeholder: 'write here...',
			callbacks: {  
				onImageUpload: function(files, editor, $editable) {  
			    	sendFile(files);
			    	//console.log('image upload:', files, editor, $editable);
		 		} 
			}
        });

        function sendFile(files, editor, $editable) {
		   
		    var data = new FormData();
            data.append("file", files[0]);
		    $.ajax({  
		        data : data,  
		        type : "POST",  
		        url : "uploadPic", //图片上传出来的url，返回的是图片上传后的路径，http格式  
		        cache : false,  
		        contentType : false,
		        processData : false,
		        success: function(data){
		            $('#summernote').summernote('insertImage', data, function ($image) {
                        $image.attr({src: data,class:"artimg"});
                    });
		        },  
		        error:function(){  
		            //alert("上传失败");  
		            console.log("上传失败");
		        }  
		    });  
		}
    });
</script>

    </div>
</body>
</html>