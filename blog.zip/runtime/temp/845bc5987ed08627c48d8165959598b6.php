<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:70:"D:\wamp\www\gz91\public/../application/myadmin\view\art\classitem.html";i:1500021553;s:68:"D:\wamp\www\gz91\public/../application/myadmin\view\layout\base.html";i:1500517064;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <title>博客后台管理系统</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" type="text/css" href="/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="/blog/css/base.css">
    <link rel="stylesheet" type="text/css" href="/blog/css/admin.css">
    <link rel="stylesheet" type="text/css" href="/blog/css/fakeloader.css">
    
<link rel="stylesheet" type="text/css" href="/summernote/summernote.css">
<style type="text/css">
	.article{margin-top: 20px;}
	.divwrap{padding-left: 15px;padding-bottom: 10px;}
	.label-name{display: inline-block;max-width: 100%;margin: 5px 0px;}
	.addart{height: 34px;line-height: 34px;}
	.explain{font-size: 12px;padding: 5px 3px;line-height: 20px;color: #666;margin-bottom: 25px;}
	thead tr th{text-align: center;}
</style>

    <script type="text/javascript" src="/bootstrap/js/jquery-1.11.3.min.js"></script>
    <script type="text/javascript" src="/bootstrap/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="/blog/js/base.js"></script>
    <script type="text/javascript" src="/blog/js/admin.js"></script> 
    <script type="text/javascript" src="/blog/js/fakeloader.min.js"></script> 
    
<script type="text/javascript" src="/summernote/summernote.min.js"></script>
 
</head>
<body>
    <div class="wrapper">
        

<div class="article">
    <div>
        <div class="divwrap"><h3>分类目录</h3></div>
	    <div class="col-md-4 col-sm-4">
	        <label for="name">添加新分类目录</label>
	     	<form role="form">
			  <div class="form-group">
			    <div for="name" class="label-name">名称</div>
			    <input type="text" class="form-control" id="name" placeholder="分类名称">
			  </div>
			  <div class="form-group">
			    <div for="name" class="label-name">父级分类目录</div>
			    <select class="form-control" id="parents">
			      <option value="0" selected="selected">无</option>
			      <?php if(isset($ret)): if(is_array($ret) || $ret instanceof \think\Collection): $i = 0; $__LIST__ = $ret;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
			      <option value="<?php echo $vo['id']; ?>"><?php echo $vo['item']; ?></option>
			      <?php endforeach; endif; else: echo "" ;endif; endif; ?>
			    </select>
			    <div class="explain">
			      分类目录和标签不同，它可以有层级关系。您可以有一个“音乐”分类目录，在这个目录下可以有叫做“流行”和“古典”的子目录。
			    </div>
			  </div>
			  <div class="form-group">
			  	<button type="submit" class="btn btn-primary" id="classadd">添加新分类目录</button>
			  </div>
			</form>
		</div>
		<div class="col-md-8 col-sm-8">
			<div class="panel panel-primary">
			    <div class="panel-heading">分类详情</div>
			    <?php if(isset($ret)): ?>
			    <table class="table table-striped text-center">
				  <thead>
				    <tr>
				      <th>选项</th>
				      <th>名称</th>
				      <th>父级目录</th>
				      <th>日期</th>
				    </tr>
				  </thead>
				  <tbody class="conts">
				    <?php if(is_array($ret) || $ret instanceof \think\Collection): $i = 0; $__LIST__ = $ret;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$ret): $mod = ($i % 2 );++$i;?>
				    <tr>
				      <td><label style="width: 100%;"><input type="checkbox" value="<?php echo $ret['id']; ?>"></label></td>
				      <td><a href=""><?php echo $ret['item']; ?></a></td>
				      <td><?php echo $ret['bm']; ?></td>
				      <td><?php echo date("Y-m-d H:i:s",$ret['addtime']); ?></td>
				    </tr>
				    <?php endforeach; endif; else: echo "" ;endif; ?>
				  </tbody>
				</table>
			</div>
			<div class="select">
				<button class="btn btn-primary" id="selted">全选/反选</button>
				<button class="btn btn-primary" id="delitem">删除所选</button>
			</div>
	        <?php else: ?>
	        <div>暂无分类</div> 
	        <?php endif; ?>
		</div>
		<div class="clearfix"></div>
	</div>
	
	<div class="fakeloader"></div>
</div>

    </div>
</body>
</html>