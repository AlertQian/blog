<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:68:"D:\wamp\www\gz91\public/../application/myadmin\view\index\index.html";i:1500521733;s:68:"D:\wamp\www\gz91\public/../application/myadmin\view\layout\base.html";i:1500517064;s:69:"D:\wamp\www\gz91\public/../application/myadmin\view\index\header.html";i:1500523302;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <title>博客后台管理系统</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" type="text/css" href="/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="/blog/css/base.css">
    <link rel="stylesheet" type="text/css" href="/blog/css/admin.css">
    <link rel="stylesheet" type="text/css" href="/blog/css/fakeloader.css">
    
    <script type="text/javascript" src="/bootstrap/js/jquery-1.11.3.min.js"></script>
    <script type="text/javascript" src="/bootstrap/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="/blog/js/base.js"></script>
    <script type="text/javascript" src="/blog/js/admin.js"></script> 
    <script type="text/javascript" src="/blog/js/fakeloader.min.js"></script> 
     
</head>
<body>
    <div class="wrapper">
         
<nav class="navbar-header">
    <div class="navbar-log"><a href="#" style="color: #fff"><span class="glyphicon glyphicon-th-list" style="padding-right: 10px;"> 
    </span>后台管理</a></div>
    <div class="user">
        <div class="dropdown">
         <div class="user-menu dropdown-toggle" id="adminmenu" data-toggle="dropdown"><img src="/blog/img/4006876523_289a8296ee.jpg" class="img-circle" height="40" width="40"><?php echo $uname; ?><span class="caret"></span></div>
         <ul class="dropdown-menu dropdown-menu-right list" role="menu" aria-labelledby="adminmenu">
            <li role="presentation">
                <a role="menuitem" tabindex="-1" href="<?php echo url('webset/administartor'); ?>" target="right"><span class="glyphicon glyphicon-user pad-right"></span>管理员</a>
            </li>
            <li role="presentation">
                <a role="menuitem" tabindex="-1" href="<?php echo url('webset/systeminfo'); ?>" target="right"><span class="glyphicon glyphicon-info-sign pad-right"></span>系统信息</a>
            </li>
            <li role="presentation">
                <a role="menuitem" tabindex="-1" href="<?php echo url('art/artadd'); ?>" target="right"><span class="glyphicon glyphicon-pencil pad-right"></span>添加文章</a>
            </li>
            <li role="presentation" class="divider"></li>
            <li role="presentation">
                <a role="menuitem" tabindex="-1" href="<?php echo url('login/loginout'); ?>"><span class="glyphicon glyphicon-log-out"></span>　退出</a>
            </li>
         </ul>
        </div>
    </div>
    <div class="web-home">
        <a href="<?php echo url('/index/index'); ?>" style="color: #fff" target="_blank"><span class="glyphicon glyphicon-home" style="padding-right: 10px;"></span>首页</a>
    </div>
</nav>
<div class="clearfix"></div>     
<div class="main">
    <div class="nav-menu">
        <div class="panel-inverse">
            <div>
                <div class="panel-heading" data-toggle="collapse" data-target="#webset" style="background: #2B2E37">
                <h4 class="panel-title"><span class="glyphicon glyphicon-globe pad-right"></span>网站管理<span class="caret"></span></h4>
                </div>
                <div id="webset" class="panel-collapse collapse in">
                    <div class="group-list">
                        <a href="<?php echo url('webset/administartor'); ?>" target="right"><span class="glyphicon glyphicon-user pad-right"></span>管理员　</a>
                        <a href="<?php echo url('webset/systeminfo'); ?>" target="right"><span class="glyphicon glyphicon-info-sign pad-right"></span>系统信息</a>
                        <a href="<?php echo url('webset/loglist'); ?>" target="right"><span class="glyphicon glyphicon-list-alt pad-right"></span>日志记录</a>
                    </div>
                </div>
            </div> 
        </div>
        <div class="panel-inverse">
            <div>
                <div class="panel-heading" data-toggle="collapse" data-target="#article" style="background: #2B2E37">
                <h4 class="panel-title"><span class="glyphicon glyphicon-folder-open pad-right"></span>文章管理<span class="caret"></span></h4>
                </div>
                <div id="article" class="panel-collapse collapse in">
                    <div class="group-list">
                        <a href="<?php echo url('art/artall'); ?>" target="right"><span class="glyphicon glyphicon-file pad-right"></span>所有文章</a>
                        <a href="<?php echo url('art/artadd'); ?>" target="right"><span class="glyphicon glyphicon-pencil pad-right"></span>添加文章</a>
                        <a href="<?php echo url('art/classitem'); ?>" target="right"><span class="glyphicon glyphicon-tags pad-right"></span>分类目录</a>
                    </div>
                </div>
            </div> 
        </div>
        <div class="panel-inverse">
            <div class="panel-heading panel-foot" data-toggle="collapse" style="background: #2B2E37">
                <span class="glyphicon glyphicon-tasks"></span>
            </div>
        </div>
        <div class="adminmenuback"></div>
    </div>
    <div class="wrap">
        <iframe id="rightag" name="right" src="<?php echo url('art/artall'); ?>" width="100%" height="100%" scrolling="no" frameborder="0"></iframe>
    </div>
    <div class="clearfix"></div>
</div>

    </div>
</body>
</html>