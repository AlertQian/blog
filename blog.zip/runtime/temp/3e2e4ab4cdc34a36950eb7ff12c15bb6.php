<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:67:"D:\wamp\www\gz91\public/../application/myadmin\view\art\artall.html";i:1500020211;s:68:"D:\wamp\www\gz91\public/../application/myadmin\view\layout\base.html";i:1500517064;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <title>博客后台管理系统</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" type="text/css" href="/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="/blog/css/base.css">
    <link rel="stylesheet" type="text/css" href="/blog/css/admin.css">
    <link rel="stylesheet" type="text/css" href="/blog/css/fakeloader.css">
    
<style type="text/css">
	.article{margin-top: 20px;}
	.divwrap{padding: 15px;}
	.glyp {top: 0px;cursor: pointer;}
	.addart{height: 34px;line-height: 34px;}
	.nocont{line-height: 30px;text-align: center;font-size: 16px;color: #f00}
	thead tr th{text-align: center;}
</style>

    <script type="text/javascript" src="/bootstrap/js/jquery-1.11.3.min.js"></script>
    <script type="text/javascript" src="/bootstrap/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="/blog/js/base.js"></script>
    <script type="text/javascript" src="/blog/js/admin.js"></script> 
    <script type="text/javascript" src="/blog/js/fakeloader.min.js"></script> 
     
</head>
<body>
    <div class="wrapper">
        

<div class="article">
    <div class="search">
	    <div class="col-md-5 col-sm-5">
		    <form method="post" action="<?php echo url('art/artall'); ?>">
				<div class="input-group">
					<input type="text" class="form-control" placeholder="标题" value="<?php echo \think\Request::instance()->param('keyword'); ?>" name="keyword">
					<span class="input-group-btn">
                        <button class="btn btn-primary" type="submit"><span class="glyphicon glyphicon-search"></span></button>
                    </span>
				</div>
			</form>	
		</div>
		<div class="col-md-7 col-sm-7 addart text-right" style="float: right;">
			<a href="<?php echo url('art/artadd'); ?>"><span class="glyphicon glyphicon-plus"></span> 添加文章</a>
		</div>
		<div class="clearfix"></div>
	</div>
	
	<div class="divwrap">
		<?php if(isset($ret)): ?>
		<table class="table table-striped text-center">
		  <caption>全部文章 <span class="badge badge-info"><?php echo $count; ?></span></caption>
		  <thead>
		    <tr>
		      <th>选项</th>
		      <th class="text-left">标题</th>
		      <th>作者</th>
		      <th>分类目录</th>
		      <th>日期</th>
		      <th>操作</th>
		    </tr>
		  </thead>
		  <tbody class="conts">
		  <?php if(is_array($ret) || $ret instanceof \think\Collection): $i = 0; $__LIST__ = $ret;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$ret): $mod = ($i % 2 );++$i;?>
		    <tr>
		      <td><label style="width: 100%;"><input type="checkbox" value="<?php echo $ret['id']; ?>" name="id"></label></td>
		      <td class="text-left"><a href=""><?php echo $ret['title']; ?></a></td>
		      <td><?php echo $ret['author']; ?></td>
		      <td><?php echo $ret['item']; ?></td>
		      <td><?php echo date("Y-m-d H:i:s",$ret['addtime']); ?></td>
		      <td><a href="<?php echo url('art/artedit',['id'=>$ret['id']]); ?>">编辑</a></td>
		    </tr>
		  <?php endforeach; endif; else: echo "" ;endif; ?>
		  </tbody>
		</table>
		<div class="select">
			<button class="btn btn-default" id="selted">全选/反选</button>
			<button class="btn btn-default" id="delart">删除所选</button>
		</div>
		<div class="page">
			<?php echo $page; ?>
		</div>
		<?php else: ?>
			<div class="nocont">没有内容</div>
		<?php endif; ?>
	</div>
	<div class="fakeloader"></div>
</div>

    </div>
</body>
</html>