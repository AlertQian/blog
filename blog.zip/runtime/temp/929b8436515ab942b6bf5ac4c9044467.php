<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:74:"D:\wamp\www\gz91\public/../application/myadmin\view\webset\systeminfo.html";i:1499420247;s:68:"D:\wamp\www\gz91\public/../application/myadmin\view\layout\base.html";i:1500517064;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <title>博客后台管理系统</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" type="text/css" href="/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="/blog/css/base.css">
    <link rel="stylesheet" type="text/css" href="/blog/css/admin.css">
    <link rel="stylesheet" type="text/css" href="/blog/css/fakeloader.css">
    
<style type="text/css">
	.admin-form{width: 800px;margin-top: 40px;}
	.til {margin-left: 30px;padding-bottom: 20px;}
	.uptime{font-size: 12px;float: right;position: relative;top: 14px;}
</style>

    <script type="text/javascript" src="/bootstrap/js/jquery-1.11.3.min.js"></script>
    <script type="text/javascript" src="/bootstrap/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="/blog/js/base.js"></script>
    <script type="text/javascript" src="/blog/js/admin.js"></script> 
    <script type="text/javascript" src="/blog/js/fakeloader.min.js"></script> 
     
</head>
<body>
    <div class="wrapper">
        

<div class="admin-form">
	<div class="til">
	    <h2>常规信息 <span class="uptime">上次更新时间：<?php echo date("Y-m-d H:i:s",$ret['addtime']); ?></span></h2>
	</div>
	<form class="form-horizontal" role="form">
	  <div class="form-group">
	    <label for="firstname" class="col-sm-2 control-label">站点标题</label>
	    <div class="col-sm-10">
	      <input type="text" class="form-control" id="title" value="<?php echo $ret['title']; ?>">
	    </div>
	  </div>
	  <div class="form-group">
	    <label for="firstname" class="col-sm-2 control-label">签名</label>
	    <div class="col-sm-10">
	      <input type="text" class="form-control" id="signature" value="<?php echo $ret['signature']; ?>">
	    </div>
	  </div>
	  <div class="form-group">
	    <label for="lastname" class="col-sm-2 control-label">站点信息</label>
	    <div class="col-sm-10">
	      <input type="text" class="form-control" id="webinfo" value="<?php echo $ret['web_info']; ?>">
	    </div>
	  </div>
	  <div class="form-group">
	    <div class="col-sm-offset-2 col-sm-10">
	      <button type="submit" class="btn btn-default" id="upinfo">保存更改</button>
	    </div>
	  </div>
	</form>
	<div class="fakeloader"></div>
</div>

    </div>
</body>
</html>