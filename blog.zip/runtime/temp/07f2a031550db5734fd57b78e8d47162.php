<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:77:"D:\wamp\www\gz91\public/../application/myadmin\view\webset\administartor.html";i:1499329132;s:68:"D:\wamp\www\gz91\public/../application/myadmin\view\layout\base.html";i:1500517064;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <title>博客后台管理系统</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" type="text/css" href="/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="/blog/css/base.css">
    <link rel="stylesheet" type="text/css" href="/blog/css/admin.css">
    <link rel="stylesheet" type="text/css" href="/blog/css/fakeloader.css">
    
<style type="text/css">
	.admin-form{width: 800px;margin-top: 40px;}
	.til {margin-left: 30px;padding-bottom: 20px;}
</style>

    <script type="text/javascript" src="/bootstrap/js/jquery-1.11.3.min.js"></script>
    <script type="text/javascript" src="/bootstrap/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="/blog/js/base.js"></script>
    <script type="text/javascript" src="/blog/js/admin.js"></script> 
    <script type="text/javascript" src="/blog/js/fakeloader.min.js"></script> 
     
</head>
<body>
    <div class="wrapper">
        

<div class="admin-form">
	<div class="til">
	    <h2>个人资料</h2>
	</div>
	<form class="form-horizontal" role="form">
	  <div class="form-group">
	    <label for="firstname" class="col-sm-2 control-label">原用户名</label>
	    <div class="col-sm-10">
	      <p class="form-control-static"><?php echo $uname; ?></p>
	    </div>
	  </div>
	  <div class="form-group">
	    <label for="firstname" class="col-sm-2 control-label">新用户名</label>
	    <div class="col-sm-10">
	      <input type="text" class="form-control" id="newname" placeholder="请输入新用户名" value="">
	    </div>
	  </div>
	  <div class="form-group">
	    <label for="lastname" class="col-sm-2 control-label">原始密码</label>
	    <div class="col-sm-10">
	      <input type="password" class="form-control" id="oldpwd" placeholder="请输原始密码">
	    </div>
	  </div>
	  <div class="form-group">
	    <label for="lastname" class="col-sm-2 control-label">新密码</label>
	    <div class="col-sm-10">
	      <input type="text" class="form-control" id="newpwd" placeholder="请输入新密码">
	    </div>
	  </div>
	  <div class="form-group">
	    <label for="lastname" class="col-sm-2 control-label">重复新密码</label>
	    <div class="col-sm-10">
	      <input type="text" class="form-control" id="againpwd" placeholder="请输入新密码">
	    </div>
	  </div>
	  <div class="form-group">
	    <div class="col-sm-offset-2 col-sm-10">
	      <button type="submit" class="btn btn-default" id="upadmin">更新</button>
	    </div>
	  </div>
	</form>
	<div class="fakeloader"></div>
</div>

    </div>
</body>
</html>