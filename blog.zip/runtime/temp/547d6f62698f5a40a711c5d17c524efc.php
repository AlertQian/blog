<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:66:"D:\wamp\www\gz91\public/../application/index\view\index\index.html";i:1500454160;s:68:"D:\wamp\www\gz91\public/../application/index\view\layout\layout.html";i:1500517323;s:65:"D:\wamp\www\gz91\public/../application/index\view\index\left.html";i:1500522680;s:68:"D:\wamp\www\gz91\public/../application/index\view\layout\footer.html";i:1500456133;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<title><?php echo (isset($title) && ($title !== '')?$title:"风雨兼程"); ?> - 钱磊的博客</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="description" content="钱磊的博客" />
    <meta name="keywords" content="钱磊的博客" />
    <meta name="author" content="钱磊"/>
    <link rel="stylesheet" type="text/css" href="/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="/blog/css/index.css">
    

    <script type="text/javascript" src="/bootstrap/js/jquery-1.11.3.min.js"></script>
	<script type="text/javascript" src="/bootstrap/js/bootstrap.min.js"></script>
	
</head>
<body>
    <div class="head visible-lg visible-md"></div>
    <div class="bodyer">
	    <div class="container">
	        <div class="row">
	            
    <div class="col-md-4 visible-lg visible-md sidebar">
    <header class="header"> 
		<h2><a href="<?php echo url('index/index'); ?>"><?php echo $ret['title']; ?></a></h2>
		<cite><?php echo $ret['signature']; ?></cite>
		<div class="items">
    	    <p>访问：<?php echo $ret['visitors_num']+1; ?>次</p>
    	    <p>文章：<?php echo $count; ?>篇</p>
	    </div>
	</header>
	<form action="<?php echo url('index/index'); ?>" method="post">
		<div class="input-group">
			<input type="text" class="form-control" value="<?php echo \think\Request::instance()->param('keyword'); ?>" name="keyword">
			<span class="input-group-btn">
	            <button class="btn btn-default" type="submit"><span class="glyphicon glyphicon-search"></span></button>
	        </span>
		</div> 
	</form>
	<br>
	<?php if(isset($newart)): ?>
	<div class="panel-group"> 
		<div class="panel panel-default">
			<div class="panel-heading" data-toggle="collapse" data-target="#new-art">
				<h4 class="panel-title">最近文章</h4>
			</div>
			<div id="new-art" class="panel-collapse collapse in">
			    <div class="list-group">
			        <?php if(is_array($newart) || $newart instanceof \think\Collection): $i = 0; $__LIST__ = $newart;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
			    	<a href="<?php echo url('index/detail',['id'=>$vo['id']]); ?>" class="list-group-item"><?php echo $vo['title']; ?><span class="badge badge-info"><?php echo date("m-d",$vo['addtime']); ?></span><div class="clearfix"></div></a>
			        <?php endforeach; endif; else: echo "" ;endif; ?>
			    </div>
			</div>
		</div> 
	</div>
	<?php endif; if(isset($itemlist)): ?>
	<div class="panel-group">
	    <div class="panel panel-default">
			<div class="panel-heading" data-toggle="collapse" data-target="#art-categories">
				<h4 class="panel-title">文章分类</h4>
			</div>
			<div id="art-categories" class="panel-collapse collapse in">
			    <div class="list-group">
			        <?php if(is_array($itemlist) || $itemlist instanceof \think\Collection): $i = 0; $__LIST__ = $itemlist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
			    		<a href="<?php echo url('index/index',['item'=>$vo['id']]); ?>" class="list-group-item"><?php echo $vo['item']; if($vo['num'] > 0): ?>
			    		<span class="badge badge-info"><?php echo $vo['num']; ?></span>
			    		<?php endif; ?>
			    		</a>
			    	<?php endforeach; endif; else: echo "" ;endif; ?>
			    </div>
			</div>
		</div>
	</div>	
	<?php endif; ?>
</div>
<div class="col-md-4 visible-xs visible-sm sidebar">
	<header class="header"> 
		<h2><?php echo $ret['title']; ?></h2>
		<cite><?php echo $ret['signature']; ?></cite>
        <button type="button" class="btn btn-default navs" data-toggle="collapse" data-target="#nav-categories"><span class="glyphicon glyphicon-th-list" style="font-size:15px;"></span></button>
		<div class="items">
    	    <p>访问：<?php echo $ret['visitors_num']+1; ?>次</p>
    	    <p>文章：<?php echo $count; ?>篇</p>
	    </div>
	</header>
    <div class="collapse" id="nav-categories">
        <form action="<?php echo url('index/index'); ?>" method="post">
	    	<div class="input-group">
				<input type="text" class="form-control" value="<?php echo \think\Request::instance()->param('keyword'); ?>" name="keyword">
				<span class="input-group-btn">
	                <button class="btn btn-default" type="submit"><span class="glyphicon glyphicon-search"></span></button>
	            </span>
			</div> 
		</form>
		<br>
		<?php if(isset($newart)): ?>
		<div class="panel-group"> 
			<div class="panel panel-default">
				<div class="panel-heading" data-toggle="collapse" data-target="#new-art">
					<h4 class="panel-title">最近文章</h4>
				</div>
				<div id="new-art" class="panel-collapse collapse in">
				    <div class="list-group">
				        <?php if(is_array($newart) || $newart instanceof \think\Collection): $i = 0; $__LIST__ = $newart;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
				    	<a href="<?php echo url('index/detail',['id'=>$vo['id']]); ?>" class="list-group-item"><?php echo $vo['title']; ?><span class="badge badge-info">442</span></a>
				        <?php endforeach; endif; else: echo "" ;endif; ?>
				    </div>
				</div>
			</div> 
		</div>
		<?php endif; if(isset($itemlist)): ?>
		<div class="panel-group">
		    <div class="panel panel-default">
				<div class="panel-heading" data-toggle="collapse" data-target="#art-categories">
					<h4 class="panel-title">文章分类</h4>
				</div>
				<div id="art-categories" class="panel-collapse collapse in">
				    <div class="list-group">
				        <?php if(is_array($itemlist) || $itemlist instanceof \think\Collection): $i = 0; $__LIST__ = $itemlist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
				    		<a href="#" class="list-group-item"><?php echo $vo['item']; if($vo['num'] > 0): ?>
				    		<span class="badge badge-info"><?php echo $vo['num']; ?></span>
				    		<?php endif; ?>
				    		</a>
				    	<?php endforeach; endif; else: echo "" ;endif; ?>
				    </div>
				</div>
			</div>
		</div>	
		<?php endif; ?>
	</div>	
</div> 
    <div class="col-md-8 content">
          <?php if(isset($artlist)): if(is_array($artlist) || $artlist instanceof \think\Collection): $i = 0; $__LIST__ = $artlist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
	      <div class="artlist"> 
    		<h2><?php echo $vo['title']; ?></h2>
	         <p>
	           <?php echo $vo['content']; ?>
	         </p>
	         <p>
	            <a class="btn" href="<?php echo url('index/detail',['id'=>$vo['id']]); ?>">View details »</a>
	         </p>
	      </div>
	      <?php endforeach; endif; else: echo "" ;endif; ?>
	      <div class="page">
	      	<?php echo $page; ?>
	      </div>
	      <?php else: ?>
	      <h2 class="text-center">没有文章</h2>
	      <?php endif; ?>
	</div>
	<div class="clearfix"></div>

		    </div>  
	    </div>
	    <div class="container footer">
	<div class="info visible-md visible-lg">copyright © 2017　　<em><?php echo $ret['web_info']; ?></em>　　<strong>Code By</strong>　AlertQian</span></div>
	<div class="row visible-sm visible-xs">
		<div class="col-md-4 text-center">copyright © 2017</div>
		<div class="col-md-4 text-center"><em><?php echo $ret['web_info']; ?></em></div>
		<div class="col-md-4 text-center"><strong>Code By</strong>　AlertQian</div>
	</div>
</div>
    </div>
</body>
</html>