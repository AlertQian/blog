<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:71:"D:\wamp\www\gz91\public/../application/myadmin\view\webset\loglist.html";i:1500255732;s:68:"D:\wamp\www\gz91\public/../application/myadmin\view\layout\base.html";i:1500517064;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <title>博客后台管理系统</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" type="text/css" href="/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="/blog/css/base.css">
    <link rel="stylesheet" type="text/css" href="/blog/css/admin.css">
    <link rel="stylesheet" type="text/css" href="/blog/css/fakeloader.css">
    


    <script type="text/javascript" src="/bootstrap/js/jquery-1.11.3.min.js"></script>
    <script type="text/javascript" src="/bootstrap/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="/blog/js/base.js"></script>
    <script type="text/javascript" src="/blog/js/admin.js"></script> 
    <script type="text/javascript" src="/blog/js/fakeloader.min.js"></script> 
    
<script type="text/javascript">
    function shap(){
    	setInterval(function(){$(".uptime").fadeOut(500).fadeIn(500);},500);
    } 
    $(function(){
    	//shap();
    })
</script>
 
</head>
<body>
    <div class="wrapper">
        
<body onload="shap()">
<div class="admin-form">
	<div class="til">
	    <h2>常规信息 <span class="uptime">上次更新时间</span></h2>
	</div>
	
	<div class="fakeloader"></div>
</div>
</body>

    </div>
</body>
</html>