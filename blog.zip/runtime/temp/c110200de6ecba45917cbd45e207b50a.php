<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:68:"D:\wamp\www\gz91\public/../application/myadmin\view\login\index.html";i:1499221434;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<title>AlertQian的博客</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link rel="stylesheet" type="text/css" href="/bootstrap/css/bootstrap.min.css">
    <script type="text/javascript" src="/bootstrap/js/jquery-1.11.3.min.js"></script>
	<script type="text/javascript" src="/bootstrap/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="/blog/css/base.css">
    <script type="text/javascript" src="/blog/js/base.js"></script>
	<style type="text/css">
	    body{background: #f1f1f1} 
		.login{width: 320px;margin-top: 8%;border: 1px solid #ccc;padding: 25px;background: #fff}
		.mid{margin-top: 30%}
		.chek{display: inline-block;}
		.subt{float: right;}
	</style>
    <script type="text/javascript" src="/blog/js/login.js"></script>
</head>
<body>
    <div class="container login">
    	<form class="form-horizontal" role="form">
    	    <div class="form-group text-center">
    	        <h2>博客登录</h2> 
    	    </div>
    		<div class="form-group">
			    <input type="text" class="form-control" id="name" placeholder="用户名">   
    		</div>
    		<div class="form-group">
			    <input type="password" class="form-control" id="pwd" placeholder="密码">
    		</div>
    		<div class="form-group">
    			<div class="checkbox chek">
			        <label><input type="checkbox" value="1" id="checkbox">请记住我</label>
			    </div>
			    <span class="subt">
			    	<button type="submit" class="btn btn-primary">登录</button>
			    </span>
    		</div>
    	</form>
    </div>
</body>
</html>