<?php
namespace app\myadmin\model;

use think\Model;

class Info extends Model
{
}