<?php
namespace app\myadmin\model;

use think\Model;

class Admin extends Model
{
}