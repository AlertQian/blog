<?php
namespace app\myadmin\model;

use think\Model;

class ClassItem extends Model
{
}